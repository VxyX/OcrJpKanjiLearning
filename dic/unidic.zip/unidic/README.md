# UniDic 2.1.2

Note the files included here are the unmodified files provided in the Unidic 2.1.2 binary distribution. 

They were originally acquired from this link:

    https://unidic.ninjal.ac.jp/back_number

Specifically:

    https://unidic.ninjal.ac.jp/unidic_archive/cwj/2.1.2/unidic-mecab-2.1.2_bin.zip

Because they are large these files are not included in the git source for unidic-lite.

